/******************************************************************************
 * Student Name    :    Jack Edwards
 * RMIT Student ID :    S3727853
 *
 * Startup code provided by Paul Miller for use in "Programmin inc C",
 * Assignment 3, study period 4, 2020.
 *****************************************************************************/
#ifndef SHARED_H
#define SHARED_H
typedef enum {FALSE, TRUE} BOOLEAN;

#endif



