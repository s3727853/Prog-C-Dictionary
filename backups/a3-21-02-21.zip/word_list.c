/******************************************************************************
 * Student Name    :    Jack Edwards
 * RMIT Student ID :    S3727853
 *
 * Startup code provided by Paul Miller for use in "Programming in C",
 * Assignment 3, study period 4, 2020.
 *****************************************************************************/
#include "word_list.h"
#include "score_list.h"

#include "shared.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <ctype.h>


/* create the functions for the management of the linked list in this file */
BOOLEAN load_dictionary(const char *filename, struct word_list* list){
    FILE *fp;
    char line[WORD_LENGTH + EXTRA_CHARS];
    char *word;
    char temp_word[WORD_LENGTH + EXTRA_CHARS];
    int i;

    fp = fopen(filename, "r");
    
    /*Iterate through file for words*/
    while(fgets(line, WORD_LENGTH + EXTRA_CHARS, fp) != NULL){
        char * token;

        /*Remove newline from word read in*/
        line[strlen(line)-1] = 0;

        /*split on newline*/
        token = strtok(line, "\n");
        
        if(token == NULL){
            printf("\nError: Empytline detected in word file");
            break;
        }
        printf("\nWord: %s", token);
        
        if(!check_letters(token)){
            printf("\nError, word has invalid characters");
            return FALSE;
        }
         
        /*Malloc space for word*/
        word = (char*)malloc((WORD_LENGTH+EXTRA_CHARS)*sizeof(char)); 
        if(!word){
            perror("Memory allocation failed");
            return FALSE;
        }
        
        /*Convert word to uppercase and copy to malloc'd memory space*/
        
        for(i=0; i< strlen(token); i++){
           temp_word[i] = toupper(token[i]);
        }
        temp_word[strlen(token)]='\0';

        strcpy(word, temp_word);

        if(!list_add2(list, word)){
            printf("\nError adding word to list.");
            return FALSE;
        }

        /*Get next token*/
        token = strtok(NULL, "\n");
    }
     

    
    /*Iterate through the dictionary and malloc each entry and add the node*/

    fclose(fp);

    return TRUE;
}

/*Check words characters are valid*/

BOOLEAN check_letters(char * token){
   int i;
   for(i = 0; i < strlen(token); i++){
       char temp;
       temp = toupper(token[i]);

       /*Defined in score_list.h ASCI values for uppercase alphabet start/end*/
       if(temp < START_LETTER_VALUE || temp > END_LETTER_VALUE){
           printf("\nInvalid character: %c in word: %s ", token[i], token); 
           return FALSE;
       }
   }
    return TRUE;
}

/******************************************************************************
* CODE REFERENCE
* Linked List is based on code provided by Paul Miller in the week 7 & 8 
* tutorial sessions.
******************************************************************************/

/* Initialise a new list*/
void list_init(struct word_list * list){
    assert(list);
   /*Zero it*/
   memset(list, 0, sizeof(struct word_list));
}

int word_cmp(const struct word_node * first, const struct word_node * second){
    int cmp;

    /*Positive if first->word is later in the sort order then second->word*/
    /*Negative if first->word is earlier in the sort order then second->word*/
   
    cmp = strcmp(first->word, second->word);
    
    /*TODO may need to check individual letters??*/
    return cmp;
}

/*add a word to the list*/
BOOLEAN list_add(struct word_list * list, const char * word){
    struct word_node * current, * previous = NULL;
    struct word_node * newnode; 
    /*Find insertion point*/

    /*Create node*/
    newnode = 
        (struct word_node *)malloc(sizeof(struct word_node));
    if(!newnode){
        perror("Memory allocation failed");
        return FALSE;
    }
 
    /*assign the word to the new node*/ 
    newnode->word = word;
    /*zero next*/
    newnode->next = NULL;
    /*if at list start then we put the node at the begining*/
    if(list->head == NULL){
        list->head = newnode;
        list->num_words ++;
        return TRUE;
    }
    for(current = list->head; current != NULL &&
            word_cmp(current,  newnode) < 0; 
            previous = current, current = current->next){
       ; 
    }        
       assert(current == NULL || previous == NULL);

       if(previous == NULL){
        /*  at list start*/
           newnode->next = list->head;
           list->head = newnode;
        /* at list end  */
       } else if(current == NULL){
            previous->next = newnode;
        /* somewhere in the middle of list  */    
       } else {
           newnode->next = current;
           previous->next = newnode;
       }
       list->num_words++;
    

    return TRUE;
}

/*Test list add version*/

BOOLEAN list_add2(struct word_list* list, const char * word){
    struct word_node* current, * previous = NULL;
    struct word_node* new;

    /*Check pointers are valid*/
    assert(list && word);
    
    /*Allocate memory*/
    new = malloc(sizeof(struct word_node));
    if(!new){
        perror("Mem allocation failed");
        return FALSE;
    }
    /*zero it*/
    memset(new, 0, sizeof(struct word_node));
    
    /*set the word pointer in the struct to point to the word. The word
     * has had memory allocated allready*/
    new->word = word;
    new->next = NULL;
    
    /*If at start of word add this new node in */
    if(list->head == NULL){
        list->head = new;
        list->num_words ++;
        return TRUE;
    }
    /*If items in list use compare function to find the insertion point*/
    current = list->head;

    while(current != NULL && word_cmp(current, new) < 0){
        previous = current;
        current = current->next;
    }

    if(previous == NULL){
        new->next = list->head;
        list->head = new;
    }
    else if(!current){
        previous->next = new;
    } else {
        previous->next = new;
        new->next = current;
    }
    list->num_words++;
    return TRUE;
}

/*Delete an element (word) from the list*/
BOOLEAN list_delete(struct word_list * list, const char * word){
    struct word_node *current, *previous = NULL;

    if(list->num_words == 0){
        printf("\nError: List is empty");
        return FALSE;
    }
    for(current = list->head; current && strcmp(current->word, word) !=0; 
            previous = current, current = current->next){
         ;
    }
    if(!current){
        printf("\nError: Word not found");
        return FALSE;
    }

    /*The element to delete is the first node*/
    if(!previous){
        list->head = list->head->next;
    } else {
        previous->next = current->next;
    }
    /*Need to free pointers in current before freeing the structure*/
    free((void *)current->word);
    free(current);
    return TRUE;
}

/*free the memory allocated to the list*/
void list_free(struct word_list * list){
    struct word_node* current, *next;
    int i = 1;
    current = list->head;

    while(current != NULL){         
        printf("Free %d ->  %s \n", i, current->word);
        /*Free the nodes & data*/ 
        next = current->next;      
        free((char*)current->word);
        free(current);
        current = next;

        i++;

    }
    
}

/*Print Dicitonary feature, utilised for testing*/
void print_list(struct word_list *list){
    struct word_node* current = list->head;
    int i = 1;

    printf("\n### Printing Linked List ###\n");
    printf("List has %li entries\n\n", list->num_words);

    while(current != NULL){
        printf("Word %d: %s\n", i, current->word);
        i++;
        current = current->next; 
    }

}

/**
 * tests whether the word specified is in the word_list and therefore a valid
 * spelling. Please see the assignment specification for further details.
 **/
BOOLEAN is_in_dictionary(struct word_list *thelist, const char *word) {
    return FALSE;
}

