/******************************************************************************
 * Student Name    :    Jack Edwards
 * RMIT Student ID :    S3727853
 *
 * Assignment 3
 *****************************************************************************/

#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include "main.h"
#include "word_list.h"
#include "io.h"

int main(int argc, char* argv[]){
    
    clock_t start, end;
    double score_time, dictionary_time;

    struct score_list *letters;
    struct word_list *words;
    char *test_string[MAX_STRING_LENGTH + EXTRA_CHARS];
    enum input_result result = IR_FAILURE;

    /*Allocate mem for word list and initilise it*/
    words = malloc(sizeof(struct word_list));
   if(!words) {
        perror("Memory allocation failed");
        return EXIT_FAILURE;
   }
   list_init(words);



    /*Check correct amount of command line arguments passed in*/
    if(argc != NUMARGS){
        printf("\nError, incorrect number of commandline arguments " 
                "passed in\n");
        return EXIT_FAILURE;
    }
    /*start timer for loading scores*/
    start = clock();
    letters = load_scores(argv[SCORELIST]);
    if(letters == NULL){
        return EXIT_FAILURE;
    }
    end = clock();
    score_time = ((double)end-start)/CLOCKS_PER_SEC;
    
    /* Load in words list */
    start = clock();
    if(!load_dictionary(argv[DICTIONARY], words)){
        printf("\nError loading word file\n");
        return EXIT_FAILURE;
    }
    
    end = clock();
    dictionary_time = ((double)end-start)/CLOCKS_PER_SEC;

    printf("\nWelcome to Wuzzle spellchecker\n"
            "--------------------------------\n");

    printf("Loading in score list took %f seconds.\n"
            "Loading in dictionary took %f\n", score_time, dictionary_time);
    
    /*Get word List load time and display here*/

    printf("Please enter the word to check the spelling of:");
    /*Call io function for input*/
    
    while(result != IR_SUCCESS){
        result = read_string_keyboard(test_string);
    }


    printf("\nYou entered: %s \n", *test_string);
    

    /*Free input that was malloced by strdup*/
    /*free(*test_string);*/


    /*Test list*/

    print_list(words);

    /*Free word_scores mem*/
    /*free(letters);*/
   
    /*Free the linked list*/

    list_free(words);
    free(*test_string);

    free(words);
    free(letters);
    return EXIT_SUCCESS;
}
