/******************************************************************************
 * Student Name    :    Jack Edwards
 * RMIT Student ID :    S3727853
 *
 * Assignment 3
 *****************************************************************************/


#include "score_list.h"

/*Order command line arguments are expected*/

#define SCORELIST 1
#define DICTIONARY 2


#define NUMARGS 3


